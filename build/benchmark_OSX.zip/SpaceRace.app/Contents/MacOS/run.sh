#!/bin/bash
cd "${0%/*}"
./SpaceRace
